import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RequestAttendanceFormComponent } from './request-attendance-form.component';

describe('RequestFormComponent', () => {
  let component: RequestAttendanceFormComponent;
  let fixture: ComponentFixture<RequestAttendanceFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RequestAttendanceFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RequestAttendanceFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
