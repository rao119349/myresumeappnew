import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {HttpService} from '../../../../_commons/service/httpService/http.service';
import {Moment} from 'moment';
import * as moment from 'moment';
import {TimepickerConfig} from 'ngx-bootstrap/timepicker';
import {InTimeInputValidator} from '../../../../_commons/_validators/timeInput.validator';
import {OutTimeInputValidator} from '../../../../_commons/_validators/timeInput.validator';
import {formatDate} from '@angular/common';
import {NgxSpinnerService} from 'ngx-spinner';

export function getTimepickerConfig(): TimepickerConfig {
  return Object.assign(new TimepickerConfig(), {
    hourStep: 1,
    minuteStep: 1,
    showMeridian: false,
    readonlyInput: false,
    mousewheel: true,
    showMinutes: true,
    showSeconds: false,
    labelHours: 'Hours',
    labelMinutes: 'Minutes',
    labelSeconds: 'Seconds',
  });
}

@Component({
  selector: 'app-request-form',
  templateUrl: './request-attendance-form.component.html',
  styleUrls: ['./request-attendance-form.component.css'],
  providers: [{provide: TimepickerConfig, useFactory: getTimepickerConfig}]

})
export class RequestAttendanceFormComponent implements OnInit {

  attendanceRequestSubmitForm: FormGroup;
  date: Moment;
  userEmployeeId: string;
  userEmployeeName: string;
  managerGuidId: string;
  managerName: string;
  workingHours: string;
  isUserAbsent = true;
  showInTimePicker = false;
  showOutTimePicker = false;
  outTimeInputClicked = false;
  requestAlreadyRaised: boolean;
  hideCheckboxCommentAndButton: boolean;
  workingLocation: string;
  inTime: Date;
  workingLocationList = [];

  constructor(private form: FormBuilder, private httpService: HttpService, private spinner: NgxSpinnerService) {
  }

  ngOnInit() {
    this.buildForm();
    this.fetchWorkingLocationCode();
    this.fetchAttendanceRecord(this.date.format('YYYY-MM-DD'));
  }

  buildForm() {
    this.attendanceRequestSubmitForm = this.form.group({
      workingLocation: ['', [Validators.required]],
      inTime: [null, [Validators.required, InTimeInputValidator()]],
      outTime: [null, [Validators.required, OutTimeInputValidator()]],
      comments: ['', [Validators.required]],
    });
  }

  get formControl() {
    return this.attendanceRequestSubmitForm.controls;
  }

  fetchWorkingLocationCode() {
    this.spinner.show('requestAttendanceForm');
    this.httpService.getRequestWithParam('singlepoint_', 'getCodes', 'workMode').subscribe(res => {
      if (res.status === 'HTTP_200') {
        this.workingLocationList = res.data;
        this.spinner.hide('requestAttendanceForm');
      } else {
        this.spinner.hide('requestAttendanceForm');
      }
    }, error => {
      this.spinner.hide('requestAttendanceForm');
    });
  }

  fetchAttendanceRecord(selectedDate) {
    this.spinner.show('requestAttendanceForm');
    const payload = {
      employeeId: this.userEmployeeId,
      selectedDate: new Date(selectedDate)
    };

    this.httpService.postRequest('singlepoint_', 'fetchAttendance', payload)
      .subscribe((res: {
        status: string,
        message: string,
        data: {
          attendance_id: number,
          inDate: string,
          outDate: string,
          inTime: string,
          outTime: string,
          workMode: number,
          requestRaised: boolean
        }
      }) => {
        if (res.status === 'HTTP_200') {
          this.requestAlreadyRaised = res.data.requestRaised;

          if (res.data.workMode) {
            this.workingLocation = res.data.workMode.toString();
            this.formControl.workingLocation.setValue(res.data.workMode.toString());
            this.formControl.workingLocation.disable();
          }

          if (res.data.inDate && res.data.inTime) {
            const dateArr = res.data.inDate.split('-');
            const timeArr = res.data.inTime.split(':');

            const date = new Date(Number(dateArr[0]), (Number(dateArr[1]) - 1), Number(dateArr[2]),
              Number(timeArr[0]), Number(timeArr[1]), Number(timeArr[2]));

            this.inTime = date;
            this.formControl.inTime.setValue(date);
            this.formControl.inTime.disable();
          }

          if (res.data.outDate && res.data.outTime) {
            const dateArr = res.data.outDate.split('-');
            const timeArr = res.data.outTime.split(':');

            const date = new Date(Number(dateArr[0]), (Number(dateArr[1]) - 1), Number(dateArr[2]),
              Number(timeArr[0]), Number(timeArr[1]), Number(timeArr[2]));
            this.formControl.outTime.setValue(date);
            this.formControl.outTime.disable();
          }

          if (res.data.outDate && res.data.outTime && res.data.inDate && res.data.inTime) {
            const inDateArr = res.data.inDate.split('-');
            const inTimeArr = res.data.inTime.split(':');
            const outDateArr = res.data.outDate.split('-');
            const outTimeArr = res.data.outTime.split(':');

            const inDate = new Date(Number(inDateArr[0]), (Number(inDateArr[1]) - 1), Number(inDateArr[2]),
              Number(inTimeArr[0]), Number(inTimeArr[1]), Number(inTimeArr[2]));
            const outDate = new Date(Number(outDateArr[0]), (Number(outDateArr[1]) - 1), Number(outDateArr[2]),
              Number(outTimeArr[0]), Number(outTimeArr[1]), Number(outTimeArr[2]));

            const workingHoursInMin = moment(outDate).diff(moment(inDate), 'minutes');
            const hoursPart = Math.floor(workingHoursInMin / 60);
            const minPart = workingHoursInMin % 60;
            this.workingHours = `${hoursPart}:${minPart}`;
            this.isUserAbsent = false;
            this.hideCheckboxCommentAndButton = true;
          }

          this.spinner.hide('requestAttendanceForm');
        }
      }, (error) => {
        this.spinner.hide('requestAttendanceForm');
      });
  }

  clickedOutside(inputName: string) {
    if (inputName === 'inTime') {
      setTimeout(() => {
        this.showInTimePicker = false;
      }, 1);
    } else {
      setTimeout(() => {
        this.showOutTimePicker = false;
      }, 1);
    }
  }


  formSubmit() {
    this.spinner.show('requestAttendanceForm');
    const formValues = this.attendanceRequestSubmitForm.getRawValue();
    if (formValues.outTime <= formValues.inTime) {
      formValues.outTime = moment(formValues.outTime);
      formValues.outTime = formValues.outTime.add(1, 'days');
      formValues.outTime = formValues.outTime.toDate();
    }
    const payload = {
        employeeId: this.userEmployeeId,
        employeeName: this.userEmployeeName,
        inTime: formatDate(formValues.inTime, 'yyyy-MM-dd\'T\'HH:mm:ss', 'en-US'),
        outTime: formatDate(formValues.outTime, 'yyyy-MM-dd\'T\'HH:mm:ss', 'en-US'),
        comments: formValues.comments,
        workLocation: parseInt(formValues.workingLocation, 10),
        approverGuid: this.managerGuidId,
      }
    ;
    this.httpService.postRequest('singlepoint_', 'submitRequestAttendance', payload).subscribe((res) => {
      this.fetchAttendanceRecord(this.date.format('YYYY-MM-DD'));
      this.isUserAbsent = true;
      this.attendanceRequestSubmitForm.reset();
      this.spinner.show('requestAttendanceForm');
    }, (error) => {
      this.spinner.hide('requestAttendanceForm');
    });
  }

  autoFillTime(inputIconName) {
    const currentTime: string = moment().format('HH:mm:ss');
    const currentDate: string = this.date.format('YYYY-MM-DD');

    const currentTimeArr: string[] = currentTime.split(':');
    const currentDateArr: string[] = currentDate.split('-');

    if (inputIconName === 'inTimeIcon') {
      if (!this.formControl.inTime.value && !this.formControl.inTime.disabled) {
        const inTime = new Date(Number(currentDateArr[0]), (Number(currentDateArr[1]) - 1), Number(currentDateArr[2]),
          Number(currentTimeArr[0]), Number(currentTimeArr[1]), Number(currentTimeArr[2]));

        this.formControl.inTime.setValue(inTime);
        this.formControl.outTime.enable();
      }
    } else {
      this.outTimeInputClicked = true;
      if (!this.formControl.outTime.value && !this.formControl.outTime.disabled) {
        const outTime = new Date(Number(currentDateArr[0]), (Number(currentDateArr[1]) - 1), Number(currentDateArr[2]),
          Number(currentTimeArr[0]), Number(currentTimeArr[1]), Number(currentTimeArr[2]));

        this.formControl.outTime.setValue(outTime);
      }
    }
  }

  iconClick(iconName: string) {
    if (iconName === 'inTimeIcon') {
      this.showInTimePicker = !this.showInTimePicker;
    } else {
      this.showOutTimePicker = !this.showOutTimePicker;
    }
    this.autoFillTime(iconName);
  }

  toggleForm() {
    this.isUserAbsent = false;
    const currentTime: string = moment().format('HH:mm:ss');
    const currentDate: string = this.date.format('YYYY-MM-DD');

    const currentTimeArr: string[] = currentTime.split(':');
    const currentDateArr: string[] = currentDate.split('-');

    const date = new Date(Number(currentDateArr[0]), (Number(currentDateArr[1]) - 1), Number(currentDateArr[2]),
      Number(currentTimeArr[0]), Number(currentTimeArr[1]), Number(currentTimeArr[2]));

    if (this.workingLocation) {
      this.formControl.workingLocation.setValue(this.workingLocation);
      this.formControl.workingLocation.disable();
    } else {
      this.formControl.workingLocation.setValue('');
    }

    if (this.inTime) {
      this.formControl.inTime.setValue(this.inTime);
      this.formControl.inTime.disable();
      this.formControl.outTime.setValue(date);
    } else {
      this.formControl.inTime.setValue(date);
      this.formControl.outTime.setValue('');
    }
  }

  clearOutTime(inTimeValue) {
    if (!inTimeValue) {
      this.formControl.outTime.setValue(null);
      this.formControl.outTime.disable();
      this.outTimeInputClicked = false;
    }
  }
}
