import {Component, ComponentFactoryResolver, ComponentRef, OnInit, ViewChild, ViewContainerRef} from '@angular/core';
import {TokenStorage} from '../../../../_commons/_helper/token-storage';
import {HttpService} from '../../../../_commons/service/httpService/http.service';
import {AttendanceFormComponent} from '../attendance-form/attendance-form.component';
import {RequestAttendanceFormComponent} from '../request-attendance-form/request-attendance-form.component';
import {Moment} from 'moment';
import * as moment from 'moment';
import {environment} from 'src/environments/environment';
import {ActivatedRoute, Router} from '@angular/router';

import {DepartmentService} from 'src/app/hays/_service/departmentService/department.service';
import {AuthService} from 'src/app/hays/_service/authService/auth.service';

import {NgxSpinnerService} from 'ngx-spinner';


@Component({
  selector: 'app-mark-attendance',
  templateUrl: './mark-attendance.component.html',
  styleUrls: ['./mark-attendance.component.css'],
})

export class MarkAttendanceComponent implements OnInit {

  homePage = environment.appSetting.homePage;
  userEmployeeId: string = this.tokenStorage.getEmployeeID();
  userEmployeeGuid: string = this.tokenStorage.getUserGuid();
  userEmployeeName: string = this.tokenStorage.getEmployeeName();
  userManagerGuidId: string = this.tokenStorage.getEmployeeManagerGuidId();
  userManagerName: string = this.tokenStorage.getEmployeeManagerName();
  todayDate: Moment = moment();
  @ViewChild('formContainer', {read: ViewContainerRef, static: true}) formContainer: ViewContainerRef;
  private componentRef: ComponentRef<AttendanceFormComponent | RequestAttendanceFormComponent>;
  userRoles = this.tokenStorage.getEmployeeRoles();
  attendanceRequest = [];
  order = false;


  constructor(private tokenStorage: TokenStorage, private httpService: HttpService,
              private resolver: ComponentFactoryResolver, private route: ActivatedRoute,
              private departmentService: DepartmentService,
              private authService: AuthService,
              private router: Router, private spinner: NgxSpinnerService) {
  }


  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params.selectedDate) {
        const gracePeriodLastDate = this.todayDate.clone().subtract(5, 'days');
        // for (let i = 0; i < 5; i++) {
        //   if (gracePeriodLastDate.day() === 1) {
        //     gracePeriodLastDate.subtract(3, 'days');
        //   } else if (gracePeriodLastDate.day() === 0) {
        //     gracePeriodLastDate.subtract(2, 'days');
        //   } else {
        //     gracePeriodLastDate.subtract(1, 'days');
        //   }
        // }
        if (moment(params.selectedDate).isBefore(gracePeriodLastDate, 'day')) {
          this.loadFormComponent('RequestAttendanceFormComponent', params.selectedDate);
        } else {
          this.loadFormComponent('AttendanceFormComponent', params.selectedDate);
        }
      } else {
        this.loadFormComponent('AttendanceFormComponent', moment().format('YYYY-MM-DD'));
      }
    });
    if ((this.userRoles.includes('PMO') || this.userRoles.includes('Functional Head') ||
      this.userRoles.includes('Manager') || this.userRoles.includes('Super Admin'))) {
      this.fetchAttendanceRequest();
    }
    if (this.authService.isLoggedIn()) {
      this.departmentService.getImportantLinks();
    }
  }

  fetchAttendanceRequest() {
    this.spinner.show('markAttendance');
    this.httpService.getRequestWithParam('singlepoint_', 'getAttendanceRequest', this.userEmployeeGuid).subscribe(res => {
      if (res.status === 'HTTP_200') {
        this.attendanceRequest = res.data;
      }
      this.spinner.hide('markAttendance');
    }, error => {
      this.spinner.hide('markAttendance');
    });
  }

  loadFormComponent(componentName, selectedDate) {
    this.formContainer.clear();
    if (componentName === 'RequestAttendanceFormComponent') {
      const factory = this.resolver.resolveComponentFactory(RequestAttendanceFormComponent);
      this.componentRef = this.formContainer.createComponent(factory);
      this.componentRef.instance.date = moment(selectedDate);
      this.componentRef.instance.userEmployeeId = this.userEmployeeId;
      this.componentRef.instance.userEmployeeName = this.userEmployeeName;
      this.componentRef.instance.managerGuidId = this.userManagerGuidId;
      this.componentRef.instance.managerName = this.userManagerName;
    }
    if (componentName === 'AttendanceFormComponent') {
      const factory = this.resolver.resolveComponentFactory(AttendanceFormComponent);
      this.componentRef = this.formContainer.createComponent(factory);
      this.componentRef.instance.date = moment(selectedDate);
      this.componentRef.instance.userEmployeeId = this.userEmployeeId;
      this.componentRef.instance.userEmployeeName = this.userEmployeeName;
    }
  }

  loadAttendanceForm(clickedDate) {
    this.router.navigate([], {relativeTo: this.route, queryParams: {selectedDate: clickedDate}});
  }

  sortData(column) {
    this.order = !this.order;
    if (this.order) {
      this.attendanceRequest.sort((a, b) => {
        if (column === 'Name') {
          return (a.employeeName ? a.employeeName : '').localeCompare(b.employeeName ? b.employeeName : '');
        }
        if (column === 'Date') {
          return (a.inDate ? a.inDate : '').localeCompare(b.inDate ? b.inDate : '');
        }
      });
    } else {
      this.attendanceRequest.sort((a, b) => {
        if (column === 'Name') {
          return (b.employeeName ? b.employeeName : '').localeCompare(a.employeeName ? a.employeeName : '');
        }
        if (column === 'Date') {
          return (b.inDate ? b.inDate : '').localeCompare(a.inDate ? a.inDate : '');
        }
      });
    }
  }
}




