import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {TimepickerConfig} from 'ngx-bootstrap/timepicker';
import {HttpService} from '../../../../_commons/service/httpService/http.service';
import * as moment from 'moment';
import {Moment} from 'moment';
import {InTimeInputValidator} from '../../../../_commons/_validators/timeInput.validator';
import {OutTimeInputValidator} from '../../../../_commons/_validators/timeInput.validator';
import {formatDate} from '@angular/common';
import {NgxSpinnerService} from 'ngx-spinner';
import {DepartmentService} from '../../../../_service/departmentService/department.service';

export function getTimepickerConfig(): TimepickerConfig {
  return Object.assign(new TimepickerConfig(), {
    hourStep: 1,
    minuteStep: 1,
    showMeridian: false,
    readonlyInput: false,
    mousewheel: true,
    showMinutes: true,
    showSeconds: false,
    labelHours: 'Hours',
    labelMinutes: 'Minutes',
    labelSeconds: 'Seconds',
  });
}

@Component({
  selector: 'app-attendance-form',
  templateUrl: './attendance-form.component.html',
  styleUrls: ['./attendance-form.component.css'],
  providers: [{provide: TimepickerConfig, useFactory: getTimepickerConfig}]
})
export class AttendanceFormComponent implements OnInit {

  attendanceSubmitForm: FormGroup;
  date: Moment;
  userEmployeeId: string;
  userEmployeeName: string;
  managerGuidId: string;  // plz dont remove from here
  managerName: string; // plz dont remove from here
  inTime: Date;
  outTime: Date;
  workingLocation = '';
  workingHours: string;
  showInTimePicker = false;
  showOutTimePicker = false;
  hideFormButton = false;
  workingLocationList = [];

  constructor(private form: FormBuilder, private httpService: HttpService, private spinner: NgxSpinnerService,
              private departmentService: DepartmentService) {
  }

  ngOnInit() {
    const currentTime: string = moment().format('HH:mm:ss');
    const currentDate: string = this.date.format('YYYY-MM-DD');

    const currentTimeArr: string[] = currentTime.split(':');
    const currentDateArr: string[] = currentDate.split('-');

    this.inTime = new Date(Number(currentDateArr[0]), (Number(currentDateArr[1]) - 1), Number(currentDateArr[2]),
      Number(currentTimeArr[0]), Number(currentTimeArr[1]), Number(currentTimeArr[2]));

    this.buildForm();
    this.fetchWorkingLocationCode();
    this.fetchAttendanceRecord(this.date.format('YYYY-MM-DD'));

  }

  buildForm() {
    this.attendanceSubmitForm = this.form.group({
      workingLocation: [{value: this.workingLocation, disabled: false}, [Validators.required]],
      inTime: [{value: this.inTime, disabled: false}, [Validators.required, InTimeInputValidator()]],
      outTime: [{value: this.outTime, disabled: true}, [Validators.required, OutTimeInputValidator()]],
    });
  }

  get formControl() {
    return this.attendanceSubmitForm.controls;
  }

  fetchWorkingLocationCode() {
    this.spinner.show('attendanceForm');
    this.httpService.getRequestWithParam('singlepoint_', 'getCodes', 'workMode').subscribe(res => {
      if (res.status === 'HTTP_200') {
        this.workingLocationList = res.data;
        this.spinner.hide('attendanceForm');
      } else {
        this.spinner.hide('attendanceForm');
      }
    }, error => {
      this.spinner.hide('attendanceForm');
    });
  }

  fetchAttendanceRecord(selectedDate) {
    this.spinner.show('attendanceForm');
    const payload = {
      employeeId: this.userEmployeeId,
      selectedDate: new Date(selectedDate)
    };

    this.httpService.postRequest('singlepoint_', 'fetchAttendance', payload)
      .subscribe((res: {
        status: string,
        message: string,
        data: {
          attendance_id: number,
          inDate: string,
          outDate: string,
          inTime: string,
          outTime: string,
          workMode: number,
          requestRaised: boolean
        }
      }) => {
        if (res.status === 'HTTP_200') {
          if (res.data.workMode) {
            this.formControl.workingLocation.setValue(res.data.workMode.toString());
            this.formControl.workingLocation.disable();
          }

          if (res.data.inDate && res.data.inTime) {
            const dateArr = res.data.inDate.split('-');
            const timeArr = res.data.inTime.split(':');

            const date = new Date(Number(dateArr[0]), (Number(dateArr[1]) - 1), Number(dateArr[2]),
              Number(timeArr[0]), Number(timeArr[1]), Number(timeArr[2]));
            this.formControl.inTime.setValue(date);
            this.formControl.inTime.disable();
          }

          if (res.data.outDate && res.data.outTime) {
            const dateArr = res.data.outDate.split('-');
            const timeArr = res.data.outTime.split(':');

            const date = new Date(Number(dateArr[0]), (Number(dateArr[1]) - 1), Number(dateArr[2]),
              Number(timeArr[0]), Number(timeArr[1]), Number(timeArr[2]));
            this.formControl.outTime.setValue(date);
            this.formControl.outTime.disable();
          }

          if (!(res.data.outDate && res.data.outTime) && (res.data.inDate && res.data.inTime)) {
            const currentTime: string = moment().format('HH:mm:ss');
            const currentDate: string = this.date.format('YYYY-MM-DD');

            const currentTimeArr: string[] = currentTime.split(':');
            const currentDateArr: string[] = currentDate.split('-');

            const date = new Date(Number(currentDateArr[0]), (Number(currentDateArr[1]) - 1), Number(currentDateArr[2]),
              Number(currentTimeArr[0]), Number(currentTimeArr[1]), Number(currentTimeArr[2]));
            this.formControl.outTime.enable();
            this.formControl.outTime.setValue(date);
          }

          if (res.data.outDate && res.data.outTime && res.data.inDate && res.data.inTime) {
            const inDateArr = res.data.inDate.split('-');
            const inTimeArr = res.data.inTime.split(':');
            const outDateArr = res.data.outDate.split('-');
            const outTimeArr = res.data.outTime.split(':');

            const inDate = new Date(Number(inDateArr[0]), (Number(inDateArr[1]) - 1), Number(inDateArr[2]),
              Number(inTimeArr[0]), Number(inTimeArr[1]), Number(inTimeArr[2]));
            const outDate = new Date(Number(outDateArr[0]), (Number(outDateArr[1]) - 1), Number(outDateArr[2]),
              Number(outTimeArr[0]), Number(outTimeArr[1]), Number(outTimeArr[2]));

            const workingHoursInMin = moment(outDate).diff(moment(inDate), 'minutes');
            const hoursPart = Math.floor(workingHoursInMin / 60);
            const minPart = workingHoursInMin % 60;
            this.workingHours = `${hoursPart}:${minPart}`;
            this.hideFormButton = true;
          }

          this.spinner.hide('attendanceForm');
        }
      }, (error) => {
        this.spinner.hide('attendanceForm');
      });
  }

  clickedOutside(inputName: string) {
    if (inputName === 'inTime') {
      setTimeout(() => {
        this.showInTimePicker = false;
      }, 1);
    } else {
      setTimeout(() => {
        this.showOutTimePicker = false;
      }, 1);
    }
  }


  formSubmit() {
    this.spinner.show('attendanceForm');
    const formValues = this.attendanceSubmitForm.getRawValue();
    if (formValues.outTime <= formValues.inTime) {
      formValues.outTime = moment(formValues.outTime);
      formValues.outTime = formValues.outTime.add(1, 'days');
      formValues.outTime = formValues.outTime.toDate();
    }

    const payload = {
      employeeID: this.userEmployeeId,
      employeeName: this.userEmployeeName,
      inTime: formatDate(formValues.inTime, 'yyyy-MM-dd\'T\'HH:mm:ss', 'en-US'),
      outTime: formValues.outTime ? formatDate(formValues.outTime, 'yyyy-MM-dd\'T\'HH:mm:ss', 'en-US') : '',
      workMode: parseInt(formValues.workingLocation, 10)
    };
    this.httpService.postRequest('singlepoint_', 'markAttendance', payload).subscribe((res) => {
      if (res.status === 'HTTP_200') {
        this.departmentService.triggerCalendarDataApi(true);
        this.fetchAttendanceRecord(this.date.format('YYYY-MM-DD'));
      }
      this.spinner.hide('attendanceForm');
    }, (error) => {
      this.spinner.hide('attendanceForm');
    });
  }

  iconClick(iconName: string) {
    if (iconName === 'inTimeIcon') {
      this.showInTimePicker = !this.showInTimePicker;
    } else {
      this.showOutTimePicker = !this.showOutTimePicker;
    }
    this.autoFillTime();
  }

  autoFillTime() {
    const currentTime: string = moment().format('HH:mm:ss');
    const currentDate: string = this.date.format('YYYY-MM-DD');

    const currentTimeArr: string[] = currentTime.split(':');
    const currentDateArr: string[] = currentDate.split('-');

    if (!this.formControl.inTime.value && !this.formControl.inTime.disabled) {
      const inTime = new Date(Number(currentDateArr[0]), (Number(currentDateArr[1]) - 1), Number(currentDateArr[2]),
        Number(currentTimeArr[0]), Number(currentTimeArr[1]), Number(currentTimeArr[2]));

      this.formControl.inTime.setValue(inTime);
    }
    if (!this.formControl.outTime.value && !this.formControl.outTime.disabled) {
      const outTime = new Date(Number(currentDateArr[0]), (Number(currentDateArr[1]) - 1), Number(currentDateArr[2]),
        Number(currentTimeArr[0]), Number(currentTimeArr[1]), Number(currentTimeArr[2]));

      this.formControl.outTime.setValue(outTime);
    }
  }


}




