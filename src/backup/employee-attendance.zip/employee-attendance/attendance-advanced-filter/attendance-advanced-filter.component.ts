import { Component, EventEmitter, Inject, Input, OnInit, Optional, Output } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';
import { MAT_DIALOG_DATA, MatDialog, MatDialogConfig, MatDialogRef } from '@angular/material/dialog';
import { HttpService } from 'src/app/hays/_commons/service/httpService/http.service';
import { MessageService } from '../../../leavers/service/messageService';
import { AttendanceDetailsComponent } from '../attendance-details/attendance-details.component';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { Observable } from 'rxjs/internal/Observable';
import { EmployeeListModel } from 'src/app/hays/_model/manager-service-models/manager-service.model';
import { TokenStorage } from 'src/app/hays/_commons/_helper/token-storage';

@Component({
  selector: 'app-attendance-advanced-filter',
  templateUrl: './attendance-advanced-filter.component.html',
  styleUrls: ['./attendance-advanced-filter.component.css']
})
export class AttendanceAdvancedFilterComponent implements OnInit {
  bsConfig: Partial<BsDatepickerConfig>;
  colorTheme = 'theme-blue';
  @Output() private onModalSubmitChange = new EventEmitter<any>();
  @Input() data: any;
  modalRef: BsModalRef;
  maxDate: Date;
  employeeResponse: EmployeeListModel[];
  formModel: any = {};

  attendanceType: any = [
    {
      id: "Absent",
      name: "Absent"
    },
    {
      id:"Present",
      name : "Present"
    },
    {
      id:"Partially Filled",
      name : "Partially Filled"
    },
    {
      id:"Weekend",
      name : "Weekend"
    }
    // {
    //   id: "Less hours in weekday",
    //   name: "Less hours in weekday"
    // }
    // , {
    //   id: "Worked on Weekend",
    //   name: "Worked on Weekend"
    // },
    // {
    //   id: "Extra Hours in Weekday",
    //   name: "Extra Hours in Weekday"
    // },
    // {
    //   id: "Temp Card Issued",
    //   name: "Temp Card Issued"
    // },
    // {
    //   id: "Full Day Leave Applied",
    //   name: "Full Day Leave Applied"
    // },
    // {
    //   id: "Half Day Leave Applied",
    //   name: "Half Day Leave Applied"
    // }
  ]

  managerRole:string[] = ["Manager","Functional Head","PMO","Super Admin"];
  isManager = false;

  constructor(private httpService: HttpService, public bsModalRef: BsModalRef,
    private spinner: NgxSpinnerService, private messageService: MessageService,private _token : TokenStorage) {
    this.bsConfig = Object.assign({}, {
      containerClass: this.colorTheme,
      dateInputFormat: 'DD-MM-YYYY',
      adaptivePosition: true,
      showPreviousMonth: true,
      showWeekNumbers:false
      
    });
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate());

    const fromDate = new Date();
    fromDate.setDate(fromDate.getDate() - 30);
    const toDate = new Date()
    this.formModel.selectedDates = [fromDate, toDate];
  }

  ngOnInit() {
    console.log("data",this.data)
    if(this.data.fromDate && this.data.toDate) {
      this.formModel.selectedDates = [this.data.fromDate, this.data.toDate];
    }
    if(this.data.attendanceType) {
      this.formModel.attendanceType = this.data.attendanceType;
    }
    if(this.data.selectedEmployee) {
      this.formModel.selectedEmployee = this.data.selectedEmployee;
    }
    let userRole = this._token.getEmployeeRoles();
    let userRoleArr = userRole.split(',');
    this.managerRole.forEach((element:any) => {
      if(userRoleArr.indexOf(element) > -1) {
        this.isManager = true;
      }
    });
    this.getEmployeesManager();
  }

  applyFilter() {    
    this.onModalSubmitChange.emit(this.formModel);
    this.bsModalRef.hide();
  }

  getDates() {
    console.log(this.formModel)
  }

  getEmployeesManager() {
    //this.spinner.show();
    this.httpService.getRequest('singlepoint_', 'getEmployeesOfManager').subscribe(Response => {
      if (Response.status === 'HTTP_200') {
        this.employeeResponse = Response.data;
      } else {
        this.employeeResponse = [];
      }
      //this.spinner.hide();
    }, error => {
      //this.spinner.hide();
    });
  }


  onClose() {
    this.bsModalRef.hide();
  }

}
