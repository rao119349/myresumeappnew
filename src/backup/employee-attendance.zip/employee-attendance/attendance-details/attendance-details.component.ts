import {Component, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Constants} from '../../../../_constants/constants';
import {HttpService} from '../../../../_commons/service/httpService/http.service';
import {TokenStorage} from '../../../../_commons/_helper/token-storage';
import {NewAttendanceModel} from '../../../../_model/employee-self-service-models/employee-self-service-models';
import {NgxSpinnerService} from 'ngx-spinner';
import {CodeResponse} from '../../../../_model/codes';
import {ModalDirective} from 'ngx-bootstrap/modal';
import {ModalService} from '../../../../_service/model/modal.service';
import {MatDialog, MatDialogConfig} from '@angular/material';
import {AttendanceAdvancedFilterComponent} from '../attendance-advanced-filter/attendance-advanced-filter.component';
import {BsModalRef, BsModalService, ModalOptions} from 'ngx-bootstrap/modal';
import {AttendanceReportExcelService} from 'src/app/hays/_commons/service/attendanceExcel/attendance-report-excel.service';
import {DatePipe} from '@angular/common';
import {environment} from 'src/environments/environment';
import {ActivatedRoute, Route, Router} from '@angular/router';


@Component({
  selector: 'app-attendance-details',
  templateUrl: './attendance-details.component.html',
  styleUrls: ['./attendance-details.component.css']
})
export class AttendanceDetailsComponent implements OnInit {
  attendanceForm: FormGroup;
  attendanceData: NewAttendanceModel[] = [];
  noDataFound: boolean;
  modalRef: BsModalRef;
  filterCriteria: any = {};
  employeeGuid: any = [];
  order = false;
  public rowsOnPageSet = [30, 50, 100];
  rowsOnPage = 30;
  config: any = {id: 'custom'};
  page = 1;
  homePage = environment.appSetting.homePage;
  searchString: string;
  selectedEmp :any = [];
  dateChips:any = {};
  resultCount:any = {};

  filterPopUpData:any = {};

  start;
  last;


  constructor(private formBuilder: FormBuilder, private modalService: ModalService,
              private httpService: HttpService,
              private bsModalService: BsModalService,
              private attendanceService: AttendanceReportExcelService,
              private tokenStorage: TokenStorage,
              private datePipe: DatePipe,
              private spinner: NgxSpinnerService,
              private router: Router,
              private activeRoute: ActivatedRoute,
  ) {
  }

  ngOnInit() {
    this.config = {itemsPerPage: this.rowsOnPage, currentPage: 1, id: 'custom'};
    const today = new Date();
    const priorDate = new Date(new Date().setDate(today.getDate() - 30));
    this.filterCriteria.fromDate = this.datePipe.transform(priorDate, 'yyyy-MM-dd');
    this.filterCriteria.toDate = this.datePipe.transform(today, 'yyyy-MM-dd');
    this.employeeGuid.push(this.tokenStorage.getUserGuid());
    this.getAttendance();
  }

  getAttendance() {
    
    this.noDataFound = false;
    this.spinner.show();

    const empGuid = this.employeeGuid.join(',');

    const requestPayload = {
      'from_date': this.filterCriteria.fromDate,
      'to_date': this.filterCriteria.toDate,
      'guid': empGuid
      //'attendance_type': this.filterCriteria.attendanceType
    };

    console.log(requestPayload);

    this.httpService.postRequest('singlepoint_', 'getAttendanceReport', requestPayload).subscribe(Response => {
      if (Response.status === 'HTTP_200') {
        this.attendanceData = [];
        const result =  Response.data;
        if(this.filterCriteria.attendanceType) {
          this.attendanceData = result.filter(s => s.Status.includes(this.filterCriteria.attendanceType))
        } else {
          this.attendanceData = result;
        }

        this.resultCount.from = this.attendanceData.length > 0 ?  1 : 0;
        this.resultCount.to = this.attendanceData.length > 0 ?  (this.attendanceData.length >=30 ?  (this.rowsOnPage > 30 ?  this.rowsOnPage: 30) : this.attendanceData.length ) : 0;
        this.resultCount.total = this.attendanceData.length;
        this.last = this.attendanceData.length > 0 ?  (this.attendanceData.length >=30 ?  (this.rowsOnPage > 30 ?  this.rowsOnPage: 30) : this.attendanceData.length ) : 0;
       
        this.attendanceData.sort((a, b) => {
            return (b.inDate ? b.inDate : '').localeCompare(a.inDate ? a.inDate : '');
        });

        this.config = {itemsPerPage: this.rowsOnPage, currentPage: 1, totalItems: this.attendanceData.length, id: 'custom'};
      } else {
        this.attendanceData = [];
        if (this.attendanceData.length === 0) {
          this.noDataFound = true;
        }
      }
      this.spinner.hide();
    });
  }

  openFilterPopup() {
    this.filterPopUpData.fromDate = new Date(this.filterCriteria.fromDate);
    this.filterPopUpData.toDate = new Date(this.filterCriteria.toDate);
    this.filterPopUpData.attendanceType = this.filterCriteria.attendanceType;
    this.filterPopUpData.selectedEmployee = this.selectedEmp;
    this.addAdvancedFilter();
  }


  addAdvancedFilter() {
    const config: ModalOptions = {
      backdrop: 'static',
      keyboard: false,
      animated: true,
      class: 'modal-dialog-centered modal-lg',
      ignoreBackdropClick: true,
      initialState: {data: this.filterPopUpData}
    };
    this.modalRef = this.bsModalService.show(AttendanceAdvancedFilterComponent, config);
    this.modalRef.content.onModalSubmitChange.subscribe((res: any) => {
      console.log('res', res);
      if (res.selectedDates) {
        this.filterCriteria.fromDate = this.datePipe.transform(res.selectedDates[0], 'yyyy-MM-dd');//res.selectedDates[0];
        this.filterCriteria.toDate = this.datePipe.transform(res.selectedDates[1], 'yyyy-MM-dd');//res.selectedDates[1];
        
        this.dateChips.fromDate = this.filterCriteria.fromDate;
        this.dateChips.toDate = this.filterCriteria.toDate;
      }

      if (res.selectedEmployee) {
        this.selectedEmp = res.selectedEmployee;
        this.employeeGuid = [];
        const selectedEmp = res.selectedEmployee;
        selectedEmp.forEach((element: any) => {
          this.employeeGuid.push(element.guid);
        });

      }
      if (res.attendanceType) {
        this.filterCriteria.attendanceType = res.attendanceType.id;
      }

      this.getAttendance();
    });
  }

   
  listCount(count) {
    this.start = count
    this.start = this.start * this.rowsOnPage - (this.rowsOnPage -1)
    this.last = count * this.rowsOnPage
    if (this.last > this.attendanceData.length) {
      this.last = this.attendanceData.length;
    }
    console.log('start'+ '      '+this.start + '      '+'last' + '      '+ this.last);
  }

  sortData(column): void {
    this.order = !this.order;
    if (this.order) {
      this.attendanceData.sort((a, b) => {
        if (column === 'Name') {
          return (a.employeeName ? a.employeeName : '').localeCompare(b.employeeName ? b.employeeName : '');
        }
        if (column === 'Date') {
          return (a.inDate ? a.inDate : '').localeCompare(b.inDate ? b.inDate : '');
        }
        if (column === 'InTime') {
          return (a.inTime ? a.inTime : '').localeCompare(b.inTime ? b.inTime : '');
        }

        if (column === 'outTime') {
          return (a.outTime ? a.outTime : '').localeCompare(b.outTime ? b.outTime : '');
        }

        if (column === 'hoursWorked') {
          return (a.hoursWorked ? a.hoursWorked : '').localeCompare(b.hoursWorked ? b.hoursWorked : '');
        }

        if (column === 'workLocation') {
          return (a.workMode ? a.workMode : '').localeCompare(b.workMode ? b.workMode : '');
        }
        if (column === 'comments') {
          return (a.comments ? a.comments : '').localeCompare(b.comments ? b.comments : '');
        }
        if (column === 'status') {
          return (a.Status ? a.Status : '').localeCompare(b.Status ? b.Status : '');
        }

      });
    } else {
      this.attendanceData.sort((a, b) => {
        if (column === 'Name') {
          return (b.employeeName ? b.employeeName : '').localeCompare(a.employeeName ? a.employeeName : '');
        }
        if (column === 'Date') {
          return (b.inDate ? b.inDate : '').localeCompare(a.inDate ? a.inDate : '');
        }
        if (column === 'InTime') {
          return (b.inTime ? b.inTime : '').localeCompare(a.inTime ? a.inTime : '');
        }

        if (column === 'outTime') {
          return (b.outTime ? b.outTime : '').localeCompare(a.outTime ? a.outTime : '');
        }

        if (column === 'hoursWorked') {
          return (b.hoursWorked ? b.hoursWorked : '').localeCompare(a.hoursWorked ? a.hoursWorked : '');
        }

        if (column === 'workLocation') {
          return (b.workMode ? b.workMode : '').localeCompare(a.workMode ? a.workMode : '');
        }
        if (column === 'comments') {
          return (b.comments ? b.comments : '').localeCompare(a.comments ? a.comments : '');
        }
        if (column === 'status') {
          return (b.Status ? b.Status : '').localeCompare(a.Status ? a.Status : '');
        }

      });

    }
  }


  downloadExcel(attendanceData: NewAttendanceModel[]) {
    let attendance: NewAttendanceModel[] = Object.assign([], attendanceData);
    attendance = JSON.parse(JSON.stringify(attendance));
    // attendance = attendance.reduce((r, c) => {
    //   c.inDate = new Date(c.inDate);
    //   r.push(c);
    //   return r;
    // }, []);
    let resultData:any =[];
    attendanceData.forEach(result => {
      let inTime  = result.inTime ? (this.datePipe.transform(new Date(result.inDate), 'dd/MM/yyyy')+' '+result.inTime.slice(0, -3)) : '';
      let outTime = result.outTime ? (this.datePipe.transform(new Date(result.outDate), 'dd/MM/yyyy')+' '+result.outTime.slice(0, -3)) : '';
      let hrs = result.hoursWorked ? result.hoursWorked.slice(0, -3) + 'Hrs' : '-'
      let data :any = {};
      data.Name = result.employeeName;
      data.Date = this.datePipe.transform(new Date(result.inDate), 'dd/MM/yyyy');
      data.InTime = inTime;
      data.OutTime = outTime;
      data.WorkedHours = hrs;
      data.WorkedLocation = result.workMode;
      data.Comments = result.comments;
      data.Status = result.Status;
      resultData.push(data)
    })
    

    console.log(resultData)
    this.attendanceService.downloadAttendance(resultData, 'Attendance Report');
  }


  handlePageSizeChange(event) {
    this.rowsOnPage = event.target.value;
    
    this.getAttendance();
    this.start = 1;
    this.last = this.rowsOnPage;
  }

  clearFilter(fieldsName:string,index?:number,guid?:String) {
    if(fieldsName == 'attendanceType') {
      this.filterCriteria.attendanceType = null;
    }
    if(fieldsName == 'date') {
      const today = new Date();
      const priorDate = new Date(new Date().setDate(today.getDate() - 30));
      this.filterCriteria.fromDate = this.datePipe.transform(priorDate, 'yyyy-MM-dd');
      this.filterCriteria.toDate = this.datePipe.transform(today, 'yyyy-MM-dd');
      this.dateChips = {};
    }

    if(fieldsName == 'employee') {
      console.log(index)
      this.selectedEmp.splice(index,1);
      this.employeeGuid.splice(index,1);
      console.log("selected emp",this.selectedEmp);
      console.log("selected guid",this.employeeGuid);
    }

    this.getAttendance();
  }

  // Commented Out because we are not sure for this feature.
  // openCalendar(date: string) {
  //   this.router.navigate(['../'], {relativeTo: this.activeRoute, queryParams: {selectedDate: date}});
  // }
}



